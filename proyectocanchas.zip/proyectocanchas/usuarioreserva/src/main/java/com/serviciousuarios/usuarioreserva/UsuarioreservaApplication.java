package com.serviciousuarios.usuarioreserva;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsuarioreservaApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsuarioreservaApplication.class, args);
	}

}
