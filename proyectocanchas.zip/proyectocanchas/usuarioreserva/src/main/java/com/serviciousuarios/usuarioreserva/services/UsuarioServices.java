package com.serviciousuarios.usuarioreserva.services;
import java.util.List;

import com.serviciousuarios.usuarioreserva.model.Usuario;

public interface UsuarioServices {

    List<Usuario> listaUsuario();

    Usuario crearUsuario(Usuario usuario);

    Usuario buscarUsuario(Long id);
    
    
}
