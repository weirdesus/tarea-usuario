package com.serviciousuarios.usuarioreserva.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.serviciousuarios.usuarioreserva.model.Usuario;
import com.serviciousuarios.usuarioreserva.repository.UsuarioRepository;

@Service
public class UsuarioServicesImpl implements UsuarioServices {
    
    @Autowired
    private UsuarioRepository usuarioRepository;

    @Override
    public List<Usuario> listaUsuario(){
        return usuarioRepository.findAll();
    }

    @Override
    public Usuario crearUsuario(Usuario usuario){
        return usuarioRepository.save(usuario);
    }

    @Override
    public Usuario buscarUsuario(Long id){
        return usuarioRepository.findById(id).orElse(null);

    }

    
}
