package com.serviciousuarios.usuarioreserva.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.serviciousuarios.usuarioreserva.model.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    
}
