package com.serviciousuarios.usuarioreserva.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.serviciousuarios.usuarioreserva.model.Usuario;
import com.serviciousuarios.usuarioreserva.services.UsuarioServices;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioServices usuarioService;

    @GetMapping
    public List<Usuario> listarUsuario(){
        return usuarioService.listaUsuario();
    }
    
    @PostMapping
    public Usuario crearUsuario(@RequestBody Usuario usuario){
        return usuarioService.crearUsuario(usuario);
    }

    @GetMapping("/{id}")
    public Usuario buscarPorUsuario(@PathVariable Long id){
        return usuarioService.buscarUsuario(id);
    }
}
